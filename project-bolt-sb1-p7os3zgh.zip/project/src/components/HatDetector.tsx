import React, { useEffect, useRef, useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import '@tensorflow/tfjs-backend-webgl';
import * as cocossd from '@tensorflow-models/coco-ssd';
import * as blazeface from '@tensorflow-models/blazeface';
import { Activity, Camera } from 'lucide-react';
import type { TrackedHat, HatDetection, ColorInfo } from '../types/hat';

const HatDetector: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('Loading models...');
  const [detections, setDetections] = useState<HatDetection[]>([]);
  const [trackedHats, setTrackedHats] = useState<Record<string, TrackedHat>>({});
  const trackedHatsRef = useRef<Record<string, TrackedHat>>({});

  useEffect(() => {
    let objectDetector: cocossd.ObjectDetection;
    let faceDetector: blazeface.BlazeFaceModel;
    let animationId: number;
    let stream: MediaStream;

    async function setupCamera(): Promise<boolean> {
      setStatus('Setting up camera...');
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setStatus('Camera access not supported by your browser');
        return false;
      }

      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            facingMode: 'user',
            width: { ideal: 640 },
            height: { ideal: 480 }
          }
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          return new Promise<boolean>((resolve) => {
            if (videoRef.current) {
              videoRef.current.onloadedmetadata = () => {
                videoRef.current?.play();
                resolve(true);
              };
            } else {
              resolve(false);
            }
          });
        }
        return false;
      } catch (error) {
        setStatus(`Camera error: ${error instanceof Error ? error.message : 'Unknown error'}`);
        return false;
      }
    }

    async function loadModels(): Promise<boolean> {
      try {
        setStatus('Setting up TensorFlow.js backend...');
        await tf.setBackend('webgl');
        await tf.ready();
        
        setStatus('Loading object detection model...');
        objectDetector = await cocossd.load();
        
        setStatus('Loading face detection model...');
        faceDetector = await blazeface.load();
        
        setStatus('Models loaded successfully');
        return true;
      } catch (error) {
        setStatus(`Error loading models: ${error instanceof Error ? error.message : 'Unknown error'}`);
        return false;
      }
    }

    function detectColor(imageData: ImageData): ColorInfo {
      const data = imageData.data;
      let r = 0, g = 0, b = 0;
      
      for (let i = 0; i < data.length; i += 4) {
        r += data[i];
        g += data[i + 1];
        b += data[i + 2];
      }
      
      r = Math.floor(r / (data.length / 4));
      g = Math.floor(g / (data.length / 4));
      b = Math.floor(b / (data.length / 4));
      
      const colorName = getColorName(r, g, b);
      return { r, g, b, colorName };
    }

    function getColorName(r: number, g: number, b: number): string {
      if (r > 200 && g < 100 && b < 100) return 'red';
      if (r < 100 && g > 200 && b < 100) return 'green';
      if (r < 100 && g < 100 && b > 200) return 'blue';
      if (r > 200 && g > 200 && b < 100) return 'yellow';
      if (r > 200 && g < 100 && b > 200) return 'purple';
      if (r < 100 && g > 200 && b > 200) return 'cyan';
      if (r > 200 && g > 150 && b > 150) return 'pink';
      if (r < 70 && g < 70 && b < 70) return 'black';
      if (r > 200 && g > 200 && b > 200) return 'white';
      return 'unknown';
    }

    function estimateDistance(faceSize: number): number {
      const maxFaceSize = 300;
      const scaleFactor = 100;
      return Math.round((scaleFactor * maxFaceSize) / faceSize);
    }

    function isLikelyHat(
      prediction: cocossd.DetectedObject,
      faceDetections: blazeface.NormalizedFace[]
    ): boolean {
      const possibleHatClasses = ['hat', 'cap', 'helmet', 'person', 'sports ball'];
      
      if (!possibleHatClasses.some(cls => prediction.class.includes(cls))) {
        for (const face of faceDetections) {
          const faceTop = face.topLeft[1];
          const faceWidth = face.bottomRight[0] - face.topLeft[0];
          
          const objBottom = prediction.bbox[1] + prediction.bbox[3];
          const objWidth = prediction.bbox[2];
          
          if (objBottom >= faceTop - 20 && 
              objBottom <= faceTop + 30 && 
              objWidth >= faceWidth * 0.5 && 
              objWidth <= faceWidth * 2) {
            return true;
          }
        }
      } else {
        return true;
      }
      
      return false;
    }

    async function detectInRealTime() {
      if (!objectDetector || !faceDetector || !videoRef.current || !canvasRef.current) return;
      
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const objectPredictions = await objectDetector.detect(video);
      const faceDetections = await faceDetector.estimateFaces(video, false);
      
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      const currentFrameHats: Record<string, TrackedHat> = {};
      const hatDetections: TrackedHat[] = [];
      
      for (const prediction of objectPredictions) {
        if (isLikelyHat(prediction, faceDetections)) {
          const [x, y, width, height] = prediction.bbox;
          const centerX = x + width/2;
          const centerY = y + height/2;
          
          try {
            const colorX = Math.floor(x + width / 4);
            const colorY = Math.floor(y + height / 4);
            const colorWidth = Math.floor(width / 2);
            const colorHeight = Math.floor(height / 2);
            
            const imageData = ctx.getImageData(colorX, colorY, colorWidth, colorHeight);
            const colorInfo = detectColor(imageData);
            
            let distance = "unknown";
            let distanceValue = null;
            let nearestFace = null;
            
            if (faceDetections.length > 0) {
              let minDistance = Infinity;
              
              for (const face of faceDetections) {
                const faceCenterX = (face.topLeft[0] + face.bottomRight[0]) / 2;
                const faceCenterY = (face.topLeft[1] + face.bottomRight[1]) / 2;
                const dx = centerX - faceCenterX;
                const dy = centerY - faceCenterY;
                const distSquared = dx*dx + dy*dy;
                
                if (distSquared < minDistance) {
                  minDistance = distSquared;
                  nearestFace = face;
                }
              }
              
              if (nearestFace) {
                const faceWidth = nearestFace.bottomRight[0] - nearestFace.topLeft[0];
                distanceValue = estimateDistance(faceWidth);
                distance = `~${distanceValue}cm`;
              }
            }
            
            const hatId = `hat_${Math.round(centerX)}_${Math.round(centerY)}_${colorInfo.colorName}`;
            
            currentFrameHats[hatId] = {
              id: hatId,
              x, y, width, height,
              centerX, centerY,
              color: colorInfo.colorName,
              colorRGB: { r: colorInfo.r, g: colorInfo.g, b: colorInfo.b },
              distance: distanceValue,
              distanceLabel: distance,
              confidence: prediction.score,
              timestamp: Date.now(),
              nearestFaceId: nearestFace ? `face_${nearestFace.topLeft.join('_')}` : null,
              velocityX: 0,
              velocityY: 0,
              distanceChange: 0,
              framesTracked: 1
            };
            
            const existingHatKey = Object.keys(trackedHatsRef.current).find(key => {
              const existing = trackedHatsRef.current[key];
              const xDiff = Math.abs(existing.centerX - centerX);
              const yDiff = Math.abs(existing.centerY - centerY);
              const sameColor = existing.color === colorInfo.colorName;
              return xDiff < 50 && yDiff < 50 && sameColor;
            });
            
            if (existingHatKey) {
              const existingHat = trackedHatsRef.current[existingHatKey];
              currentFrameHats[existingHatKey] = {
                ...existingHat,
                x, y, width, height,
                centerX, centerY,
                distance: distanceValue,
                distanceLabel: distance,
                confidence: prediction.score,
                timestamp: Date.now(),
                velocityX: centerX - existingHat.centerX,
                velocityY: centerY - existingHat.centerY,
                distanceChange: existingHat.distance ? distanceValue - existingHat.distance : 0,
                framesTracked: (existingHat.framesTracked || 0) + 1
              };
              
              delete currentFrameHats[hatId];
              hatDetections.push(currentFrameHats[existingHatKey]);
            } else {
              hatDetections.push(currentFrameHats[hatId]);
            }
            
          } catch (e) {
            console.error("Error analyzing color:", e);
          }
        }
      }
      
      trackedHatsRef.current = {...currentFrameHats};
      
      const currentTime = Date.now();
      Object.keys(trackedHatsRef.current).forEach(key => {
        if (currentTime - trackedHatsRef.current[key].timestamp > 2000) {
          delete trackedHatsRef.current[key];
        }
      });
      
      Object.values(currentFrameHats).forEach(hat => {
        const {x, y, width, height, colorRGB, color, distanceLabel, framesTracked} = hat;
        
        const lineWidth = Math.min(5, 1 + Math.floor(framesTracked / 10));
        ctx.strokeStyle = `rgb(${colorRGB.r}, ${colorRGB.g}, ${colorRGB.b})`;
        ctx.lineWidth = lineWidth;
        ctx.strokeRect(x, y, width, height);
        
        ctx.fillStyle = `rgba(${colorRGB.r}, ${colorRGB.g}, ${colorRGB.b}, 0.7)`;
        ctx.fillRect(x, y - 30, width, 30);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '16px Arial';
        ctx.fillText(`${color} hat, ${distanceLabel}`, x + 5, y - 10);
        
        ctx.font = '12px Arial';
        ctx.fillText(`ID: ${hat.id.substring(0, 8)}`, x + 5, y + height + 15);
        
        if (Math.abs(hat.velocityX) > 1 || Math.abs(hat.velocityY) > 1) {
          ctx.beginPath();
          ctx.moveTo(hat.centerX, hat.centerY);
          ctx.lineTo(hat.centerX + hat.velocityX * 3, hat.centerY + hat.velocityY * 3);
          ctx.strokeStyle = 'yellow';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      });
      
      setTrackedHats(trackedHatsRef.current);
      
      const results: HatDetection[] = hatDetections.map(hat => ({
        id: hat.id.substring(0, 8),
        type: 'Hat',
        color: hat.color,
        distance: hat.distanceLabel,
        confidence: hat.confidence.toFixed(2),
        framesTracked: hat.framesTracked,
        moving: Math.abs(hat.velocityX) > 1 || Math.abs(hat.velocityY) > 1 ? 'Yes' : 'No'
      }));
      
      setDetections(results);
      setLoading(false);
      
      animationId = requestAnimationFrame(detectInRealTime);
    }

    async function init() {
      const cameraReady = await setupCamera();
      if (!cameraReady) return;
      
      const modelsReady = await loadModels();
      if (!modelsReady) return;
      
      detectInRealTime();
    }

    init();

    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto p-4">
      <div className="flex items-center gap-3 mb-4">
        <Camera className="w-8 h-8 text-blue-600" />
        <h1 className="text-2xl font-bold">Hat Detection with Color Analysis</h1>
      </div>
      
      {loading && (
        <div className="mb-4 p-4 bg-blue-50 text-blue-700 rounded flex items-center gap-2">
          <Activity className="w-5 h-5 animate-pulse" />
          {status}
        </div>
      )}
      
      <div className="relative w-full max-w-lg bg-white p-4 rounded-lg shadow-lg">
        <video
          ref={videoRef}
          className="w-full rounded-lg"
          playsInline
          style={{ display: 'none' }}
        />
        <canvas
          ref={canvasRef}
          className="w-full rounded-lg"
        />
      </div>
      
      <div className="mt-6 w-full bg-white p-6 rounded-lg shadow-lg">
        <div className="flex items-center gap-2 mb-4">
          <Activity className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-semibold">Detected Hats ({Object.keys(trackedHats).length})</h2>
        </div>
        
        {detections.length === 0 ? (
          <p className="text-gray-500 italic">No hats detected yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="p-3 text-left border">ID</th>
                  <th className="p-3 text-left border">Color</th>
                  <th className="p-3 text-left border">Distance</th>
                  <th className="p-3 text-left border">Confidence</th>
                  <th className="p-3 text-left border">Tracked Frames</th>
                  <th className="p-3 text-left border">Moving</th>
                </tr>
              </thead>
              <tbody>
                {detections.map((item, index) => (
                  <tr key={index} className="hover:bg-gray-50 transition-colors">
                    <td className="p-3 border font-mono text-sm">{item.id}</td>
                    <td className="p-3 border">
                      <div className="flex items-center gap-2">
                        <span 
                          className="inline-block w-4 h-4 rounded-full" 
                          style={{backgroundColor: item.color}}
                        />
                        <span>{item.color}</span>
                      </div>
                    </td>
                    <td className="p-3 border">{item.distance}</td>
                    <td className="p-3 border">{item.confidence}</td>
                    <td className="p-3 border">{item.framesTracked}</td>
                    <td className="p-3 border">
                      <span className={`px-2 py-1 rounded-full text-sm ${
                        item.moving === 'Yes' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {item.moving}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      <div className="mt-8 p-6 bg-white rounded-lg shadow-lg w-full">
        <h3 className="text-lg font-semibold mb-4">How it works</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium mb-2">Detection Features</h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full" />
                Object detection identifies potential hats
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full" />
                Face detection confirms placement
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full" />
                Color analysis determines hat color
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full" />
                Distance estimation via face size
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">Tracking System</h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full" />
                Persistent IDs for each hat
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full" />
                Movement tracking with vectors
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full" />
                Distance change monitoring
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full" />
                Statistical tracking
              </li>
            </ul>
          </div>
        </div>
        <p className="mt-4 text-sm text-gray-600">
          This system uses TensorFlow.js for real-time object detection and tracking.
          The tracking system can follow multiple hats simultaneously, maintaining
          unique IDs and monitoring movement patterns.
        </p>
      </div>
    </div>
  );
};

export default HatDetector;